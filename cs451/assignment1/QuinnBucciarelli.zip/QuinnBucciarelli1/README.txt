README.txt

Colin Quinn and Elena Bucciarelli

File name: psely.c

compile psely.c by running `gcc psely.c` and execute with `./a.out`.
Doing so will output a less formatted version of the command `ps -ely`.
There are no parameters that need to be input for compilation.

The only differences between this output and the normal output of the command 
is that time is formatted as `0:0:0`. Sometimes a dash is included in that time,
we don't know why. 

The demo file includes the copy pasted version of that CLI output from our written command.
