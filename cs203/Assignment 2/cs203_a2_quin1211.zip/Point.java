
public class Point {

	int x, y;
	int index;
	
	public Point(int x2, int y2, int num) {
		x = x2;
		y = y2;
		index = num;
	}
	
	//get the coordinates of this point
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public int getIndex() {
		return index;
	}
	
}
