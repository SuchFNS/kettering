/*
Colin Quinn
Lab 4: CS 231
Use pipes and stdin/stdout redirection to spell check
a file of words against a dictionary list of words
*/

#include <stdio.h>
#include <string.h>

const int MAX = 25;

/*
Empty string passed in as param
*/
void emptyStr(char *str){
	int i = 0;
	while (i < MAX){
		str[i] = '\0';
		i++;
	}
}

/*
Assuming each list is sorted, determine whether or 
not the words in the input file are spelled correctly
relying on ASCII values and determining if one is 
greater than the other
*/
int main(int argc, char **argv){
	
	char input[MAX];
	char dict[MAX];
	int difference;
	
	//initialize strings
	emptyStr(input);
	emptyStr(dict);
	
	//open dictionary file to read
	FILE * dictionary;
	if (dictionary = fopen(argv[2], "r")){

		fgets(input, MAX, stdin);
		fgets(dict, MAX, dictionary);
//printf("%s\t%s",  input, dict);

		//while not at the end of either file
		while(input != NULL  || dict != NULL){
			
			//checks the input file and dictionaries
			difference = strncmp(input, dict, MAX);
			
			//determine if words are equal
			//get next dictionary input if it is not NULL
			if(difference > 0){
				if(fgets(dict, MAX, dictionary) == NULL){
					break;
				}
				
			//passed value in dictionary, therefore not found and move on if not at end of list
			}else if (difference < 0){
				printf("Word is NOT spelled correctly: %s", input);	
				if (fgets(input, MAX, stdin) == NULL){
					break;
				}
			
			//else word is found in dictionary
			}else if (difference == 0){
				printf("Word is spelled correctly: %s", input);
				fgets(input, MAX, stdin);
				fgets(dict, MAX, dictionary);
			}
//printf("%s\t%s", input, dict);
		}
		
		//finish list of words if end of dictionary is found
		while((fgets(input, MAX, stdin)) != NULL){
			printf("Word is NOT spelled correctly: %s", input);
		}
	
	//error statement for dictionary not being found
	}else printf("Error: Dictionary file not found");
	
	return 0;

}
