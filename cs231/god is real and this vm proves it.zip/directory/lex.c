/*
Colin Quinn
Lab 4: CS 231
Use pipes and stdin/stdout redirection to spell check
a file of words against a dictionary list of words
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>

//start of program to read file and output contents
int main(int argc, char **argv){

	//assign file names to files
	FILE *input;
	input = fopen(argv[1], "r");
	
	//read from word input file & output
	char word[20];
	while(fgets(word, 20, input)!=NULL){
		int i = 0;
		while (word[i] != '\0'){
			if(!(isalpha(word[i])) && (word[i] != '\n')) {
				word[i] = '\n';
			}
			i++;
		}
		//print strings line by line
		printf("%s", word);
		
	}
	fclose(input);
	return 0;
}

