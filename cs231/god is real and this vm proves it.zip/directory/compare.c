/*
Colin Quinn
Lab 4: CS 231
Use pipes and stdin/stdout redirection to spell check
a file of words against a dictionary list of words
*/

#include <stdio.h>
#include <string.h>
#include <unistd.h>

const int MAX = 100;

/*
Empty string that is passed in as param
*/
void emptyStr(char *str){
	int i = 0;
	while (i < MAX){
		str[i] = '\0';
		i++;
	}
}

/*
Assuming each list is sorted, determine whether or 
not the words in the input file are spelled correctly
relying on ASCII values and determining if one is 
greater than the other
*/
int main(int argc, char **argv){
	
	char input[MAX];
	char dict[MAX];
	int difference;
	
	//initialize strings
	emptyStr(input);
	emptyStr(dict);
	
	//open dictionary file to read
	FILE * dictionary;
	if (dictionary = fopen(argv[1], "r")){
		
		//gets first inputs of each file
		fgets(input, MAX, stdin);
		fgets(dict, MAX, dictionary);

		//continue until end of either file is reached
		while(input != NULL || dict != NULL){
			//compare each string
			difference = strncasecmp(dict, input, MAX);
			
			if (difference == 0){
				printf("Word is spelled correctly: %s", input);
				//move on to next word to spell check if not at end of file
				if ((fgets(input, MAX, stdin)) == NULL){
					break;
				}
			}else if (difference < 0){
				//check next word in dictionary
				if ((fgets(dict, MAX, dictionary)) == NULL){
					break;
				}
			}else if (difference > 0){
				printf("Word is NOT spelled correctly: %s", input);
				//move on to next word of stdin
				if ((fgets(input, MAX, stdin)) == NULL){
					break;
				}
			}
		
		}
		printf("Complete\n");

	//error statement for dictionary not being found
	}else printf("Error: Dictionary file not found");
	
	fclose(dictionary);
	return 0;
}
