/*
Colin Quinn
Lab 4: CS 231
Use pipes and stdin/stdout redirection to spell check
a file of words against a dictionary list of words
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/wait.h>
#include <signal.h>

int pid_id[4];
char *pid_names[4];
int count;
FILE * spellOutput;

void handler(int, siginfo_t *, void *);

int main(int argc, char **argv){

	//reap info from children upon death
	struct sigaction sigact;
 
  sigact.sa_sigaction = handler;
  sigact.sa_flags = SA_SIGINFO; //get information about signal
  sigfillset(&sigact.sa_mask);
  sigdelset(&sigact.sa_mask, SIGCHLD);
  sigaction(SIGCHLD, &sigact, NULL);

	//signal(SIGCHLD, SIGTERM);
	
	//start with no children
	count = 0;
	
	//open spellCheck.log
	spellOutput = fopen("spellCheck.log", "w");
	
	//names of pid's
	pid_names[0] = "lex.out";
	pid_names[1] = "sort";
	pid_names[2] = "uniq";
	pid_names[3] = "compare.out";
	
	//list of args to pass through each pipe
	char *args[3];
	args[0] = "./lex.out";
	args[1] = argv[1];
	args[2] = NULL;
	
	char *sort[2];
	sort[0] = "sort";
	sort[1] = NULL;
	
	char *uniq[3];
	uniq[0] = "uniq";
	uniq[1] = "-i";
	uniq[2] = NULL;
	
	char *comp[3];
	comp[0] = "./compare.out";
	comp[1] = argv[2];
	comp[2] = NULL;	

	//creates the pipes needed
	int pi[2];
	int pi2[2];
	int pi3[2];
	
	//open first pipe
	pipe(pi);
	
	//create the first child by fork() to lex.out
	if ((pid_id[0] = fork()) == 0){
		close(pi[0]);
		dup2(pi[1], STDOUT_FILENO);
		
		close(pi[1]);
		execvp("./lex.out", args);
	}
	//open second pipe
	pipe(pi2);
	
	//fork output from lex.out to sort function
	if((pid_id[1] = fork()) == 0){
		close(pi[1]);
		dup2(pi[0], STDIN_FILENO);
		close(pi[0]);
		
		close(pi2[0]);
		dup2(pi2[1], STDOUT_FILENO);
		close(pi2[1]);
		execvp(sort[0], sort);
	}
	//close pipe 1
	close(pi[0]);
	close(pi[1]);
	
	//open third pipe
	pipe(pi3);
	
	//fork output from sort to uniq
	if((pid_id[2] = fork()) == 0){
		close(pi2[1]);
		dup2(pi2[0], STDIN_FILENO);
		close(pi2[0]);
		
		close(pi3[0]);
		dup2(pi3[1], STDOUT_FILENO);
		close(pi3[1]);
	
		execvp(uniq[0], uniq);
	}
	//close pipe 2
	close(pi2[0]);
	close(pi2[1]);
	
	//fork output from uniq to compare.out to print to console
	if((pid_id[3] = fork()) == 0){
		close(pi3[1]);
		dup2(pi3[0], STDIN_FILENO);
		close(pi3[0]);
		
		execvp("./compare.out", comp);
	}
	//close pipe 3
	close(pi3[0]);
	close(pi3[1]);

	//continue until 4 children have died
	while(count < 4);

	//close spellCheck.log
	fclose(spellOutput);
	
}

//handler based off of example found at:
// https://kettering.blackboard.com/webapps/blackboard/execute/displayIndividualContent?mode=view&content_id=_468619_1&course_id=_39153_1
void handler(int signum, siginfo_t * si, void * ucontext){

	pid_t pid;
	int status;
	int pidNum;
	char output[200];
	if (signum == SIGCHLD){
		while ((pid = waitpid(-1, &status, WNOHANG)) > 0){
			if (pid == pid_id[0]){
				pidNum = 0;
			}else if (pid == pid_id[1]){
				pidNum = 1;
			}else if (pid == pid_id[2]){
				pidNum = 2;
			}else if (pid == pid_id[3]){
				pidNum = 3;
			}
			count++;
			//format line for output to file
			sprintf(output, "Process with ID of: %d with name of %s died.\n", pid_id[pidNum], pid_names[pidNum]);
			fputs(output, spellOutput);
				
		}
  	}
	
}

