/*
Programmed by: Colin Quinn
CS 231 - 03l
Recreate the cat function within Linux.
allow user to input the files they want to 
see/concatenate, then output the results to 
command line.
*/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <stdarg.h>

/*
Call to check if there are any commands input
in the form of '-' or '-(letter)'
*/
void checkCommands(char **args, char *flags){

	int i = 1;
	int j = 0;
	while (args[i] != NULL){
		if (args[i][0] == '-'){
			strcat(flags, args[i]);
			j++;
		}
		i++;
	}
}

/*
Take the input from the files opened and 
make the proper adjustments on them from command
input list
*/
int fileCopy(char *buff, char *arg, char *flags, int lineNum){
    int c;
	char line[100];
    FILE *rf;
    rf = fopen(arg, "r");
    if (rf){
    
    	//check flags for changes needed
    	//if no commands
    	if(*flags == '\0'){
    		while((c= fgetc(rf)) != EOF){
    			putchar(c);
    		}
    		fclose(rf);
    		return 0;
    		
    	//if only b is input, or if b and n
    	}else if((strchr(flags, 'b') != NULL && (strchr(flags, 'E') == NULL && strchr(flags, 'n') == NULL)
    		|| (strchr(flags, 'b') != NULL && strchr(flags, 'n') != NULL && (strchr(flags, 'E') == NULL)))){
    		while(fgets(line, 100, rf)){ 
    			if(line[0] != '\n'){  		
    				printf("     %d  ", lineNum);
    				lineNum++;
    				printf("%s", line);
    			}else printf("\n");
  	 		}
    		fclose(rf);
   			return lineNum;
   			
   		//if only E is input for commands
    	}else if(strchr(flags, 'E') != NULL && (strchr(flags, 'b') == NULL && strchr(flags, 'n') == NULL)){
    		while((c= fgetc(rf)) != EOF){
    			if(c == '\n'){
    				putchar('$');
    				putchar('\n');
    			}else putchar(c);
    		}
    		fclose(rf);
    		return 0;
    		
    	//if only n
    	}else if (strchr(flags, 'n') != NULL && strchr(flags, 'b') == NULL && strchr(flags, 'E') == NULL){
    		while(fgets(line, 100, rf)){   		
    			printf("     %d  ", lineNum);
    			lineNum++;
    			printf("%s", line);
    			
  	 		}
    		fclose(rf);
   			return lineNum;
    	
    	//if E and b, or if E and b and n
    	}else if (strchr(flags, 'b') != NULL && strchr(flags, 'E') != NULL && (strchr(flags, 'n') == NULL)
    	|| (strchr(flags, 'b') != NULL && strchr(flags, 'n') != NULL && (strchr(flags, 'E') != NULL))){
    		while(fgets(line, 100, rf)){ 
    			if(line[0] != '\n'){  		
    				printf("     %d  ", lineNum);
    				lineNum++;
    				printf("%s\n", line);
    			}else printf("\n");
  	 		}
    		fclose(rf);
    		return lineNum;
    	
    	//if E and n
    	}else if (strchr(flags, 'E') != NULL && strchr(flags, 'n') != NULL && strchr(flags, 'b') == NULL){
    		while(fgets(line, 100, rf)){   		
    			printf("     %d  ", lineNum);
    			lineNum++;
    			int i = 0;
    			while(line[i] != '\n'){
    				printf("%c", line[i]);
    				i++;
    			}
    			printf("$\n");
    			
  	 		}
    		fclose(rf);
   			return lineNum;	
    	}
   	}else printf("%s file not found\n", arg);
    
}

/*
Open a file and read the contents to the command console
*/
void consoleOutput(char **args, char *flags){
	
	char *buffer = malloc(100 * sizeof(char));
	int line = 1;
	
	int index = 1;
	while (args[index] != NULL){
		//find commands
		if (args[index][0] == '-' && args[index][1] == '\0'){
			//allow user input until ^d is input
			int exitNum = 0;
			while(exitNum != EOF){
				exitNum = scanf("%s", buffer);
			}
			
		}else if (args[index][0] == '-' && args[index][1] != '\0'){
			/*case for command with letter, do nothing as it
			was already found and handled */
			
		}else if (args[index][0] != '-'){
			//open this file name and output contents with changes
			line = fileCopy(buffer, args[index], flags, line);
		}
		index++;
	}
	//free memory
	free(buffer);
}

/*
Main function, start of program
*/
int main(int argc, char * argv[]){
	char *flags = malloc(15 * sizeof(char));

	//find the commmands from input
	checkCommands(argv, flags);

	//method call to output everything to console for user
	consoleOutput(argv, flags);
	
	free(flags);

}

