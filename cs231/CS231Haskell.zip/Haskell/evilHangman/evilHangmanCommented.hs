{-
Colin Quinn & Nathan Veit
Lab 8, Haskell Evil Hangman
------------------------------
Create a hangman game that does not select
the winning word until the game is over.
Take command line input for base rules of game,
allow for usual hangman steps to be taken where 
the program searches for the longest set of words
and selects that list, continuing on until guesses 
are expended. Select winner and repeat if wanted.
-}

module Main where

import System.IO
import System.Environment
import System.Exit (exitSuccess)
import Data.Char
import Data.List
import Text.Read

--checks for certain argument conditions
--numOfArgs :: [String]
numOfArgs = do
  args <- getArgs 
  let lengthOfArgs = length args
  if lengthOfArgs == 4 || lengthOfArgs == 3 then do
   if lengthOfArgs == 4 then return args
   --cons a string in the position where -n would otherwise be
   else return $ args ++ ["no -n"]
  else exitSuccess

--verify that word length is valid
lengthCheck :: Int -> Int
lengthCheck length
  | length < 30 && length /= 27 && length > 0 = length 
  | otherwise = 0 

--verify that number of guesses is valid
guessCheck :: Int -> Int
guessCheck guess
  | guess >= 0 && guess < 16 = guess
  | guess >= 15 = 15
  | otherwise = -1

--convert string to upper case
upper string = map toUpper string

--find the words with desired length
findWords :: [String] -> Int -> [String]
findWords word len
  |word == [] = []
  --adds words of desired length to the list returned to main
  |length (head word) == len = [head word] ++ findWords (tail word) len
  |otherwise = [] ++ findWords (tail word) len

--makes sure that upon completing a game, the user enters valid information
handleUserInput :: String -> String -> IO()
handleUserInput userInput nCase = do
  let upperUserInput = upper userInput
  --if user enters Y or N then continue based on choice
  if upperUserInput == "Y" || upperUserInput == "N" then do
    if (upperUserInput == "Y") then do
     gameRestart nCase
    else do
     putStrLn "Goodbye!"
     exitSuccess
  --else keep asking until valid input is entered
  else do 
     putStrLn "Please enter Y or N"
     reType <- getLine
     handleUserInput reType nCase
  
{-
If the user enters Y to continue playing the game then get 
all changes to the information needed to continue playing 
with new instances of length and amount of guesses
-}
gameRestart :: String -> IO()
gameRestart nCase = do
  --get new inputs for word length and guess amount
  putStrLn "Enter the new word length.\n"
  wordLengthInput <- getLine
  let wordLength = read wordLengthInput :: Int
  putStrLn "Enter the new guess length.\n"
  guessLengthInput <- getLine
  let guessLen = read guessLengthInput :: Int 
  let length = lengthCheck wordLength
  let guess = guessCheck guessLen
  --reread dicitonary.txt file
  dictTemp <- readFile "dictionary.txt"
  let dictionary = words dictTemp
  let upperDict = map upper dictionary
  let wordList = findWords upperDict length
  --restart game loop with new information
  let lettersGuessed = ""
  let initialWord = createInitialWord length
  startGame wordList guess nCase lettersGuessed initialWord

--hits if the user guessed the word
gameWin :: String -> String -> IO()
gameWin finalWord nCase = do
  putStrLn "Congratualtions you actually managed to win!"
  putStrLn $ "The word was : " ++ finalWord 
  putStrLn "Would you like to play again? (Y/N)"
  do 
   --asks player to play again
   userInput <- getLine
   handleUserInput userInput nCase

--game over runs when user runs out of guesses
gameLoss :: [String] -> String -> IO()
gameLoss listOfWords nCase = do
  putStrLn $ "Game over! Sorry you ran out of guesses. The word was: " ++ (head listOfWords)
  putStrLn "\nWould you like to play again? (Y/N)"
  do 
   --asks user to play again
   userInput <- getLine
   handleUserInput userInput nCase
  
--determine what to output based on -n command and state of game
printOutput :: [String] -> Int -> String -> String -> String -> IO()
printOutput listOfWords guesses nCase lettersGuessed currentWord
  | isInfixOf "_" currentWord == False = gameWin currentWord nCase
  | nCase == "-n" && guesses > 0 = do 
    putStrLn $ "Number of guesses left: " ++ (show guesses) ++ "\nLetters Guessed: " ++ lettersGuessed ++ "\nCurrent Word: " ++ currentWord ++ "\nWords remaining: " ++ (show $ length listOfWords)
  | nCase /= "-n" && guesses > 0 = do 
    putStrLn $ "Number of guesses left: " ++ (show guesses) ++ "\nLetters Guessed: " ++ lettersGuessed ++ "\nCurrent Word: " ++ currentWord
  |otherwise = gameLoss listOfWords nCase

--Starts the game loop
startGame :: [String] -> Int -> String -> String -> String -> IO()
startGame wordList guesses nCondition lettersGuessed currentWord = do
  putStrLn "The game is starting!"
  printOutput wordList guesses nCondition lettersGuessed currentWord
  

--create the original blank word
createInitialWord :: Int -> String
createInitialWord wordLength
  |wordLength > 1 = "_ " ++ createInitialWord (wordLength - 1)
  |otherwise = "_"

--start program here
main = do 
  -- get the command line arguments
  [dict, lengthIn, guessIn, n] <- numOfArgs
  dictTemp <- readFile dict
  let dictionary = words dictTemp
  --convert from string to integer
  let wordLen = read lengthIn :: Int
  let guessLen = read guessIn :: Int
  --check validity of all inputs
  let length = lengthCheck wordLen
  let guess = guessCheck guessLen
  let nCondition = n
  --decide if program should shut down or not
  if length == 0 then do
    putStrLn "Incorrect length"  
    exitSuccess
  else return()
  if guess == -1 then do
    putStrLn "Incorrect guess amount"
    exitSuccess
  else return()
  
  --convert full dictionary to upper case
  let upperDict = map upper dictionary
  
  --find list of words at desired length
  let wordList = findWords upperDict length
    
  --MAIN GAME LOOP THAT GOES HERE	
  let lettersGuessed = ""
  let initialWord = createInitialWord wordLen
  startGame wordList guess nCondition lettersGuessed initialWord
  --temporary output for main
  putStrLn "end of main"