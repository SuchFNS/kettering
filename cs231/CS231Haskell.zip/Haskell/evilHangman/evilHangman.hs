{-
Colin Quinn & Nathan Veit
Lab 8, Haskell Evil Hangman
------------------------------
Create a hangman game that does not select
the winning word until the game is over.
Take command line input for base rules of game,
allow for usual hangman steps to be taken where 
the program searches for the longest set of words
and selects that list, continuing on until guesses 
are expended. Select winner and repeat if wanted.
-}

module Main where

import System.IO
import System.Environment
import System.Exit (exitSuccess)
import Data.Char
import Data.List

{-
  numOfArgs checks to make sure the proper number of arguments have been entered. If there
  are four arguments it returns all those arguments. If there are 3 it adds a string saying 
  there is no -n and adds that to the list of args.
  
  DATA TABLE 
  
  Variable			Description
  args				the arguments from when the program is run
  lengthOfArgs		an integer of the number of args
-}
numOfArgs = do
  args <- getArgs 
  let lengthOfArgs = length args
  if lengthOfArgs == 4 || lengthOfArgs == 3 then do
   if lengthOfArgs == 4 then return args
   --cons a string in the position where -n would otherwise be
   else return $ args ++ ["no -n"]
  else exitSuccess

{-
  lengthCheck takes in an integer representing the length of the word and checks to make sure it's 
  a valid number. If it is 30 or greater, 27, or one or less it returns 0.
  
  DATA TABLE
  
  Variable			Description
  lenght			integer representing the length of word entered
-}
lengthCheck :: Int -> Int
lengthCheck length
  | length < 30 && length /= 27 && length > 1 = length 
  | otherwise = 0 

{-
  guessCheck takes in an integer number of guesses to make sure it is a proper number.
  If it is 0 or less it returns negative one. IF it is greater than 15 it returns 15.
  
  DATA TABLE
  
  Variable			Description
  guess				integer representing number of guesses entered
-}
guessCheck :: Int -> Int
guessCheck guess
  | guess > 0 && guess < 16 = guess
  | guess >= 15 = 15
  | otherwise = -1

--convert string to upper case
upper string = map toUpper string

{-
  findWords adds all the words of a desired length to a list that is returned to the 
  program.
  
  DATA TABLE
  
  Variable			Description
  word				list of all the words in the dictionary
  len				the length of the words desired
-}
findWords :: [String] -> Int -> [String]
findWords word len
  |word == [] = []
  --adds word of desired length to list to be returned then continues recursively
  |length (head word) == len = [head word] ++ findWords (tail word) len
  --continues recursively
  |otherwise = [] ++ findWords (tail word) len

{-
  handleUserInput takes in a string that was previously entered by the player
  and checks to make sure that it is correct input to restart the game. If it is 
  not it asks for the input again and rechecks. If the input was a Y it calls a function 
  to restart the game. Otherwise the program ends.
  
  DATA TABLE
  
  Variable			Description
  userInput			String previously entered by player
  nCase				String that says whether or not the user has a -nCase
  upperUserInput	User input converted to upper case
  reType			New input from the user
-}
handleUserInput :: String -> String -> IO()
handleUserInput userInput nCase = do
  let upperUserInput = upper userInput
  --if user enters Y or N then continue based on choice
  if upperUserInput == "Y" || upperUserInput == "N" then do
    --calls function to restart the game
    if (upperUserInput == "Y") then do
     gameRestart nCase
    else do
     --ends the program
     putStrLn "Goodbye!"
     exitSuccess
  --else keep asking until valid input is entered
  else do 
     putStrLn "Please enter Y or N"
     reType <- getLine
     handleUserInput reType nCase
  
{-
  gameRestart is run if the user enters Y to continue playing the game then get 
  all changes to the information needed to continue playing 
  with new instances of length and amount of guesses
  
  DATA TABLE 		Variable
  nCase				String containing either -n condition or "no -n"
  wordLengthInput	String from user representing new word length
  wordLength		wordLengthInput represented as an Int
  guessLengthInput	String from user representing new amount of guesses
  guessLen			guessLengthInput represented as an Int
  dicitonary		list of all the words in the dictionary
  upperDict			dictionary converted to upper case
  wordList			list of all the words of a desired length
  lettersGuessed	empty string signifying the user has not guessed a letter
  initialWord		a string with underscores of desired length
-}
gameRestart :: String -> IO()
gameRestart nCase = do
  --get new inputs for word length and guess amount
  putStrLn "Enter the new word length."
  wordLengthInput <- getLine
  let wordLength = read wordLengthInput :: Int
  putStrLn "Enter the new amount of guesses."
  guessLengthInput <- getLine
  let guessLen = read guessLengthInput :: Int 
  let length = lengthCheck wordLength
  let guess = guessCheck guessLen
  if length == 0 then do
    putStrLn "Incorrect length"  
    exitSuccess
  else return()
  if guess == -1 then do
    putStrLn "Incorrect guess amount"
    exitSuccess
  else return()
  --reread dicitonary.txt file
  dictTemp <- readFile "dictionary.txt"
  let dictionary = words dictTemp
  let upperDict = map upper dictionary
  let wordList = findWords upperDict length
  --restart game loop with new information
  let lettersGuessed = ""
  let initialWord = createInitialWord length
  printOutput wordList guess nCase lettersGuessed initialWord

{-
  gameWin is hit if the player manages to guess the word. It prints out a message
  telling the player they won and asks if they want to play again. It then calls a 
  function to handle this input.
  
  DATA TABLE
  
  Variable			Description
  userInput			String entered by the player in the terminal
-}
gameWin :: String -> String -> IO()
gameWin finalWord nCase = do
  --prints message stating that the player won and asks to play again
  putStrLn "Congratualtions you actually managed to win!"
  putStrLn $ "The word was : " ++ finalWord 
  putStrLn "Would you like to play again? (Y/N)"
  do 
   --gets unput from the player
   userInput <- getLine
   handleUserInput userInput nCase

{-
  gameLoss is triggered when the player runs out of guesses. It prints out
  a message informing the player that they lost and asks if they want to play 
  again. It then calls a function to handle the players input.
  
  DATA TABLE
  
  Variable			Description
  userInput			String entered by the player in the terminal
-}
gameLoss :: [String] -> String -> IO()
gameLoss listOfWords nCase = do
  --prints message telling the player they lost and asks if they want to play again
  putStrLn $ "Game over! Sorry you ran out of guesses. The word was: " ++ (head listOfWords)
  putStrLn "\nWould you like to play again? (Y/N)"
  do 
   --gets input from the player
   userInput <- getLine
   handleUserInput userInput nCase
  
{-
  printOutput prints the number of guesses the player has left, the letters guessed, the current word
  and if applicable the number of words remaining. It also checks if the player won based on if the current word
  has a dah in it or if the player lost if they are out of guesses.
  
  DATA TABLE
  
  Variable			Description
  listOfWords		list of all possible words left
  guesses			number of guesses the player has left
  nCase				string on whether or not the game started with a -nCase
  lettersGuessed	string of all the letters the player guessedLetter
  currentWord		string of the current / updated dashed word
-}
printOutput :: [String] -> Int -> String -> String -> String -> IO()
printOutput listOfWords guesses nCase lettersGuessed currentWord = do
  --checks if there is a dash in the current word and calls a win if there is not
  if isInfixOf "_" currentWord == False 
    then gameWin currentWord nCase
  else return()
  --prints output including number of words if the user has more guesses
  if nCase == "-n" && guesses > 0 then do
    putStrLn $ "Number of guesses left: " ++ (show guesses) ++ "\nLetters Guessed: " ++ (intersperse ' ' (sort lettersGuessed)) ++ "\nCurrent Word: " ++ currentWord ++ "\nWords remaining: " ++ (show $ length listOfWords)
    --return to the main game
    mainGame listOfWords guesses nCase lettersGuessed currentWord
  --prints output without number of words if the user has more guesses
  else
    if nCase /= "-n" && guesses > 0 then do 
      putStrLn $ "Number of guesses left: " ++ (show guesses) ++ "\nLetters Guessed: " ++ (intersperse ' ' (sort lettersGuessed)) ++ "\nCurrent Word: " ++ currentWord
      --return to the main game
      mainGame listOfWords guesses nCase lettersGuessed currentWord
    --calls a loss as the user is out of guesses
    else gameLoss listOfWords nCase
  
{-
  mainGame takes in a player guess and checks to make sure it's a valid guess. It adds the guess to
  the guessed letters and gets a new pattern group. It then updates the current word based on the new pattern.
  If the new current word is equal to the old current word it calls print output with a decremented number
  of guesses. Otherwise it prints output without decrementing guesses.
  
  DATA TABLE
  
  Variable				Description
  listOfWords			list of all applicable words
  guesses				number of guesses remaining
  nCase					string on whether or not there is a -nCase
  lettersGuessed		string of all the letters that have been guessedLetter
  currentWord			the blank word containing dashes
  newGuess				gets a string from the player
  upperGuess			user input upper case
  newLettersGuessed		String with the new guess added
  pattern				the updated pattern
  newDash				the new word based of dashes
  newWord				adds spaces to the newDash
  
-}
mainGame :: [String] -> Int -> String -> String -> String -> IO()
mainGame listOfWords guesses nCase lettersGuessed currentWord = do
  --gets guess from player
  putStrLn "Enter your guess: "
  newGuess <- getLine  
  let upperGuess = upper newGuess
  --checks to make sure the guess is a valid guess
  if length upperGuess == 1 && isInfixOf upperGuess lettersGuessed == False && isAlpha (head upperGuess) then do
   --add new guessed letter to other guessed letters
   let newLettersGuessed = lettersGuessed ++ upperGuess
   --find new word group based on input current list of words and new letter input
   changedGroup <- changeGroup listOfWords (head upperGuess)
   --find the pattern of the new group of words 
   let pattern = getPattern (head upperGuess) (head changedGroup)
   --replace dash with new letter if it is in the word
   let newDash = putLetter pattern (words currentWord)
   --add spaces between each char in the string
   let newWord = intersperse ' ' newDash
   --determines if the old current word is the same as the new one and prints output accordingly
   if newWord == currentWord then do
     printOutput changedGroup (guesses - 1) nCase newLettersGuessed newWord
   else
     printOutput changedGroup guesses nCase newLettersGuessed newWord
  
  else do
  --asks the user the enter a valid guess
   putStrLn "Please enter a single, unused letter"
   mainGame listOfWords guesses nCase lettersGuessed currentWord

{-
  putLetter takkes in the pattern and the list of words and checks if there are spaces.
  If the head of the pattern is a space it adds the first word and calls with the other
  letters in the pattern and word list. Otherwise it adds the list of the head of the pattern
  with the the putLetter of the rest of the pattern and word list
  
  DATA TABLE
  
  Variable			Description
  pattern			the word pattern passed in
  currentWord		the list of all viable words
-}  
putLetter :: String -> [String] -> String
putLetter pattern currentWord
  | pattern == [] = []
  | (head pattern) == ' ' = (head currentWord) ++ putLetter (tail pattern) (tail currentWord)
  | otherwise = [(head pattern)] ++ putLetter (tail pattern) (tail currentWord)

{-
  changeGroup finds the new family by taking in the list of words and the guessed letter.
  It then gets a list of patterns back, sorts them from most words to least and gets the
  pattern with the most words.
  
  DATA TABLE
  
  Variable				Description
  listOfWords			the list containing all applicable words
  guessedLetter			the letter the player had guessedLetter
  spaces 				gets spaces in replace of chars that are not the guessed char
  listOfSpaces			sorts spaces and groups them by likeness
  maxGroup				sorts the groups by most to least elements
  newPatternList		the list with the most elements
-}   
changeGroup :: [String] -> Char -> IO[String]
changeGroup listOfWords guessedLetter = do
  let spaces = map (getPattern guessedLetter) listOfWords
  let listOfSpaces = group $ sort spaces
  --sorts the patterns with the most words before the smaller patterns
  let maxGroup = maximumBy (\x y -> compare (length x) (length y)) listOfSpaces
  --gets the pattern with the most words
  let newPatternList = findPattern listOfWords (head maxGroup) guessedLetter  
  return (newPatternList)

{-
  findPattern checks if the pattern of a certain word matches matches with the current pattern.
  If it does, it adds it to the words of that pattern.
  
  DATA TABLE
  
  Variable				Description
  currentPattern		
  guessedLetter
-}
findPattern :: [String] -> String -> Char -> [String]
findPattern listOfWords currentPattern guessedLetter
  | listOfWords == [] = []
  --word matches pattern adds word
  | (getPattern guessedLetter (head listOfWords)) == currentPattern = [head listOfWords] ++ findPattern (tail listOfWords) currentPattern guessedLetter
  --word does not match
  | otherwise = [] ++ findPattern (tail listOfWords) currentPattern guessedLetter

--apply makeSpaces to every char the passed in string
getPattern :: Char -> String -> String
getPattern input word = map (makeSpaces input) word

{-
  called from getPattern, compares the char guessed and each char of a string.
  If the two elements are not equal, make the current char = a space
  
  DATA TABLE
  
  Variable				Description
  char1					user input char guess
  char2					char from the word called with makeSpaces
-}
makeSpaces :: Char -> Char -> Char
makeSpaces char1 char2
  | char1 == char2 = char1
  | otherwise = ' '

{-
  createInitialWord takes in the word length and creates a dashed word of
  that specified length
  
  DATA TABLE
  
  Variable			Description
  wordLength		the length of the word the user previously specified
-}
createInitialWord :: Int -> String
createInitialWord wordLength
  --adds a dash and a space to string returned
  |wordLength > 1 = "_ " ++ createInitialWord (wordLength - 1)
  -- adds just a dash 
  |otherwise = "_"

{-
  main takes in the initial arguments and checks to make sure that they are of the correct
  values before passing them on to the rest of the game.
  
  DATA TABLE
  
  Variable				Description
  dict					dictionary text file
  lengthIn				input word length
  guessIn				input guess ammount
  n						string that should contain a -n
  dicitonary			all the words in the dictionary file in a list
  dictTemp				read in of the dictionary file
  wordLen				lengthIn converted to an Int
  guessLen				guessIn converted to an Int
  nCondition			string containing a -n or no -nCase
  length				the actual length the game plays with
  guess					the actual amount of guesses the game plays with
  upperDict				the list of words converted to upper case
  wordList				all the words of a desired length
  lettersGuessed		blank string indicating no letters have been guessedLetter
  initialWord			the intitial dashed pattern of the word
-}
main = do 
  -- get the command line arguments
  [dict, lengthIn, guessIn, n] <- numOfArgs
  dictTemp <- readFile dict
  let dictionary = words dictTemp
  --convert from string to integer
  let wordLen = read lengthIn :: Int
  let guessLen = read guessIn :: Int
  --check validity of all inputs
  let length = lengthCheck wordLen
  let guess = guessCheck guessLen
  let nCondition = n
  --decide if program should shut down or not
  if length == 0 then do
    putStrLn "Incorrect length"  
    exitSuccess
  else return()
  if guess == -1 then do
    putStrLn "Incorrect guess amount"
    exitSuccess
  else return()
  
  --convert full dictionary to upper case
  let upperDict = map upper dictionary
  
  --find list of words at desired length
  let wordList = findWords upperDict length
    
  --MAIN GAME LOOP THAT GOES HERE	
  let lettersGuessed = ""
  let initialWord = createInitialWord wordLen
  printOutput wordList guess nCondition lettersGuessed initialWord