--Colin Quinn
module MakeSquares where

solve :: String -> [Int]
--split input line and call to recursive function
solve input = solveRec(map read $ words input :: [Int])
  --rectangleSides = map read $ words input
  --solveRec (head rectangleSides) (tail rectangleSides)

solveRec :: [Int] -> [Int]
{-
recurse through squares, adding smallest
element to the list, then subtracting that 
element from the larger side until sides are 
equal.
-}
solveRec inputs
  | head inputs == last inputs = [head inputs]
  | head inputs > last inputs = last inputs : solveRec [(head inputs - last inputs) , last inputs]
  | head inputs < last inputs = head inputs : solveRec [(last inputs - head inputs), head inputs]
