{-
Colin Quinn
CS 231: Haskell lab 3
Spell check a list of words by 
comparing the values to that of 
the words to that of the dictionary


readFile/writeFile for input/output
nub to remove duplicates of words
https://hackage.haskell.org/package/case-insensitive-match
-}

import System.Environment
import System.IO 
import Data.List
import Data.Char

--make everything not whitespace into whitespace
remove:: String -> String
remove xs
  | xs == []         =[]
  | isAlpha $head xs = [head xs]++(remove $ tail xs)
  | otherwise        =[' ']++(remove $ tail xs)

--make string lowercase w/o effecting actual case
lower string = map toLower string


--compare input file with dictionary file
compareWords :: [String] -> [String] -> String
compareWords input dictionary
  | null input = ""
  | lower (head input) == lower (head dictionary) = head input ++ " is spelled correctly\n" ++ compareWords (tail input) (tail dictionary)
  | lower (head input) > lower (head dictionary) = compareWords input (tail dictionary)
  | lower (head input) < lower (head dictionary) = head input ++ " is spelled incorrectly\n" ++ compareWords (tail input) dictionary


main = do
  --get the command line arguments as a string list
  [input, dictionary, output] <- getArgs
  
  --read the input file, split string by whitespace into a list
  stringInput <- readFile input
  let inputs = words $ remove stringInput
  
  --read dictionary file and split by whitespace
  dictionaryInput <- readFile dictionary
  let dictionary = words dictionaryInput
  
  --sort the input list
  let sortedIn = sortBy (\x y -> compare (lower x) (lower y)) inputs
  
  --delete duplicates within input list
  let finalIn = nubBy (\x y -> lower x == lower y) sortedIn

  writeFile output (compareWords finalIn dictionary)
  --call to check equality of all strings from input and write to file
 