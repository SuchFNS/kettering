{-
Colin Quinn & Nathan Veit
Lab 8, Haskell Evil Hangman
------------------------------
Create a hangman game that does not select
the winning word until the game is over.
Take command line input for base rules of game,
allow for usual hangman steps to be taken where 
the program searches for the longest set of words
and selects that list, continuing on until guesses 
are expended. Select winner and repeat if wanted.
-}

module Main where

import System.IO
import System.Environment
import System.Exit

lengthCheck :: Integer -> Integer
lengthCheck length
  | length < 30 && length /= 27 && length > 0 = length 
  | otherwise = 0 

guessCheck :: Integer -> Integer
guessCheck guess
  | guess > 0 && guess < 16 = guess
  | guess > 15 = 15
  | otherwise = 0

nCheck :: String -> Bool
nCheck n
  | n == "-n" = True
  | otherwise = False

main = do 
  [dict, lengthIn, guessIn, n] <- getArgs
  dictTemp <- readFile dict
  let dictionary = words dictTemp
  let wordLen = read lengthIn :: Integer
  let guessLen = read guessIn :: Integer
  --check validity of all inputs
  let length = lengthCheck wordLen
  let guess = guessCheck guessLen
  let lastIn = nCheck n
  if length == 0 then putStrLn "Incorrect length"
  else if guess == 0 then putStrLn "incorrect guess amount"
  else print "continuing"
  
  
  
  putStrLn "hi"