#Colin Quinn
#Cloud Computing Assignment 4
#This will serve as a connection point for peers to
#obtain IP's of other users that are interested in
#sharing similar information.
#Will receive the client's IP and port number in order
#to forward information to the next client that joins.
#The next client connects and is given the information
#that it needs to perform the data transfer.

import socket, sys

#create a socket
server=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
firstSocket = True
clientPort=""
clientIP=""
host = socket.gethostname()
port = int(sys.argv[1])

#bind the socket to a hostname and port
server.bind((host, port))
server.listen(3)

#continue until the server is stopped
while True:
    #wait for a client to connect
    client, addr = server.accept()

    #output where the client connected from
    print("User Connected from address: " + str(addr))

    #check if client is the first to connect,
    #if yes, tell client that it is the server peer and keep IP
    if firstSocket:
        client.send("server".encode('UTF-8'))
        clientPort = client.recv(1024).decode('UTF-8')
        clientIP = addr[0]
        print("The connected server peer is at port: " + clientPort)
        firstSocket = not firstSocket

    #if not first to connect, give the IP and port number of the
    #server peer
    else:
        clientString = "client:"+clientIP+":"+clientPort
        client.send(clientString.encode('UTF-8'))
        firstSocket = not firstSocket
    #close the client after termination
    client.close()
