#Colin Quinn
#Cloud Computing Assignment 4
#Acts as the client in a peer to peer conversation
#reads a book and picks the 50 most common words of
#at least length 5. It then connects to the IP and port
#of either another server peer, or becomes the server
#peer. It then waits for a message to be sent/received
#and then sends the data that was processed about the
#book that it had read. It will compare its own book
#data with the data that it receives from the other
#peer, and output the combined list of most used
#words and the sum of the words across both books.

import socket
import os
import sys
import os.path
import pickle
from collections import Counter

def compareBooks(dataList):
    outputList = []
    #create list of most used words and their counts
    words, count = zip(*dataList)

    for word in mostCommon.most_common(50):
	#check if word is in both most used lists
        if word[0] in words:
	    #append current word and count to outputList
            amount = count[words.index(word[0])]
            outputList.append((word[0], word[1]+amount))

    #sort outputList based on the count values
    outputList = sorted(outputList, key=lambda x: x[1])
    #reverse outputList to display the larger values first
    outputList.reverse()

    #output the list of most used words
    print ("Word\t\tCount")
    for pair in outputList:
        print(pair[0].ljust(16)+str(pair[1]))

#code for the case of the peer being the first to connect,
#forces that peer to be the host of the network
def becomeServer(port):
    #make this client the host server, based on a given port
    cs = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    host = socket.gethostname()
    cs.bind((host, port))
    #allow for 5 different connections
    cs.listen(5)

    #receive IP and connect to the new peer
    oc, addr = cs.accept()
    print("New Connection from client peer")

    #exchange friendly messages between client and server
    oc.send("Hi! It is nice to meet you!".encode('UTF-8'))
    print("Sent a message to new client peer, Hi! it is nice to meet you!")

    message = oc.recv(1024).decode('UTF-8')
    print("Message received from client peer: " + message)

    #receive a pcikled book from the client and unpack it
    data = oc.recv(4096)
    dataList = pickle.loads(data)

    #pickle your own book and send it to the client
    ownBook = pickle.dumps(mostCommon.most_common(50))
    oc.send(ownBook)
    print("My book data has been sent to the new peer")

    #compare the two books and close the connection
    compareBooks(dataList)
    oc.close()

def becomeClient(port, IP):
    #if either the port or the IP was not received
    #stop
    if port=='' or IP =='':
        print("Some error occurred.. disconnecting")
        sys.exit(0)

    #retrieve the hostname
    serverName = socket.gethostbyaddr(IP)
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    #make a connection and exchange friendly banter
    print("Connecting to the server peer")
    server.connect((serverName[0], int(port)))
    print("Connection Accepted")

    message = server.recv(1024).decode('UTF-8')
    print("Message received from server peer: " + message)

    server.send("Nice to meet you as well!".encode('UTF-8'))
    print("Sent a message to server peer")

    #pickle the list of the most common words in the book
    data = pickle.dumps(mostCommon.most_common(50))
    server.send(data)
    print("My book data has been sent")

    #receive the list from the server and unpack it
    sBook = server.recv(4096)
    bookList = pickle.loads(sBook)
    compareBooks(bookList)
    server.close()


#BEGIN MAIN CODE

#check current folder for the book, if not found, then download from link given
if not os.path.exists("863-0.txt"):
    fileBook = os.system('wget http://www.gutenberg.org/files/863/863-0.txt')
#read in the book as a text file
book = open("863-0.txt", mode="r")

#make all char lowercase to accurately count the number of each word
contents = book.read().lower()
correctedContents =""

#remove all non alphabetic chars from input
for letter in contents:
    if letter.isalpha():
        correctedContents+=letter
    else:
        correctedContents+=" "

#create list of words split on a space char
words = correctedContents.split(" ")

#erase all words shorter than 5 chars
fiveLetterWords = []
for word in words:
    if len(word) >=5:
        fiveLetterWords.append(word)
mostCommon = Counter(fiveLetterWords)

#connect to the server
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = sys.argv[1]
port = int(sys.argv[2])
s.connect((host, port))

print("Thank you for connecting from Torrent Server")
name = s.recv(1024).decode('UTF-8')

#cases to handle server/client peer
if name == "server":
    print("Torrent server says that I am the host peer")
    s.send((sys.argv[3]).encode('UTF-8'))
    s.close()
    becomeServer(int(sys.argv[3]))

#case to handle a new client peer
elif "client" in name:

    items = name.split(":")

    print("Torrent server says that I am a peer")

    print("Requesting host peer's IP address")
    IPClient = items[1]
    print("Received IP address: " + IPClient)

    print("Requesting host peer's port number")
    portClient = items[2]
    print("Received port: " + portClient)

    #close the socket and become a client again
    s.close()
    becomeClient(portClient, IPClient)

